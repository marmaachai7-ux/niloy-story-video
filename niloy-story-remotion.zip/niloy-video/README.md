# নিলয়ের গল্প — Remotion প্রজেক্ট (1920×1080, 30fps)

## চালানোর ধাপ
1. `npm install`
2. প্রিভিউ: `npx remotion studio src/index.ts`
3. রেন্ডার: `npx remotion render src/index.ts NiloyStory out/niloy-story.mp4 --codec=h264`

## ফাইল-গাইড
- `public/voice.mp3` — ভয়েসওভার
- `src/data.ts` — SRT ক্যাপশন, সংলাপ-বাবল, কার্ড, সিন-টাইমিং, চ্যানেলের নাম (`CHANNEL_NAME`)
- `src/kit/` — Character, আইকন, ব্যাকগ্রাউন্ড, বাবল/কার্ড/ক্যাপশন (পুনর্ব্যবহারযোগ্য)
- `src/scenes/` — সিনগুলো (S1S2, S3S4, S5S6S7, S8S9)
- `src/Video.tsx` — সব সিন + অডিও সাজানো
