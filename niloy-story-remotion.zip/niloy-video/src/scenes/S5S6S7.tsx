import React from 'react';
import {Frame, popio, pop, ramp, useT, win, lerpPos} from '../kit/core';
import {Character, NILOY, TITHI, Expr} from '../kit/Character';
import {Shop, Home, MoBg} from '../kit/bg';
import {Phone, Multimeter, Solder, Charger, Key, Check, Cross, Smoke, Calendar, Notebook, Bulb, Torch} from '../kit/icons';
import {Pill, InfoCard} from '../kit/ui';
import {CARD} from '../data';

const BenchTable: React.FC<{x0?: number; w?: number}> = ({x0 = 300, w = 1000}) => (
  <g>
    <rect x={x0} y={790} width={w} height={30} rx={8} fill="#8a6238" stroke="#222" strokeWidth={4} />
    <rect x={x0 + 30} y={820} width={w - 60} height={170} fill="#6f4d2a" stroke="#222" strokeWidth={4} />
  </g>
);

export const S5a: React.FC = () => {
  const t = useT();
  const nx = t < 96.2 ? 800 : lerpPos(t, 96.2, 98.4, 800, -250);
  const walking = t >= 96.2;
  const ra = ramp(t, 93.8, 94.6, 7, 80) - ramp(t, 94.6, 96.0, 0, 25);
  return (
    <>
      <Frame>
        <Shop />
        {/* করিম কাকার টেবিল ও খালি চেয়ার */}
        <rect x={980} y={770} width={600} height={26} rx={8} fill="#8a6238" stroke="#222" strokeWidth={4} />
        <rect x={1000} y={796} width={560} height={134} fill="#6f4d2a" stroke="#222" strokeWidth={4} />
        <rect x={1620} y={640} width={110} height={26} rx={8} fill="#b5473d" stroke="#222" strokeWidth={4} />
        <rect x={1600} y={560} width={26} height={110} rx={8} fill="#b5473d" stroke="#222" strokeWidth={4} />
        <rect x={1660} y={666} width={18} height={264} fill="#5c4326" stroke="#222" strokeWidth={3} />
        {t >= 96 && <Key x={1060} y={752} s={0.8} />}
        <Character id="niloy" cfg={NILOY} x={nx} y={930} walk={walking} expr="neutral" look={1} pose={{l: 7, r: ra}} holdR={t < 96 ? <Key s={0.8} /> : undefined} />
      </Frame>
      <Pill t0={92.9} t1={97} text="পরদিন সকাল" />
    </>
  );
};

export const S5b: React.FC = () => {
  const t = useT();
  const states = (i: number): 'dead' | 'burnt' | 'on' => (i < 2 && t >= 109.4 ? 'burnt' : i === 2 && t >= 111 ? 'on' : 'dead');
  const nExpr: Expr = t < 113 ? 'neutral' : 'tired';
  return (
    <>
      <Frame>
        <Home dark={0.3} />
        <Character id="niloy" cfg={NILOY} x={800} y={990} expr={nExpr} pose="hold" look={0.7} />
        <BenchTable />
        {t >= 101.7 && <g transform={`translate(560,${740 + (1 - Math.min(1, pop(t, 101.7))) * -40})`}><Multimeter s={0.52 * Math.min(1.1, pop(t, 101.7))} value="0.00" /></g>}
        {t >= 103.2 && <g transform={`translate(900,${776 + (1 - Math.min(1, pop(t, 103.2))) * -40})`}><Solder s={0.7 * Math.min(1.1, pop(t, 103.2))} /></g>}
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const a = pop(t, 105.6 + i * 0.28, 0.3);
          return a > 0 ? (
            <g key={i}>
              <Phone x={1000 + i * 56} y={742} s={0.56 * Math.min(1.1, a)} state={states(i)} />
              {i < 2 && t >= 111 && <Cross x={1000 + i * 56} y={680} s={0.45} />}
              {i === 2 && t >= 113 && <Check x={1000 + i * 56} y={680} s={0.45} />}
              {i < 2 && win(t, 109.4, 112.5) && <Smoke x={1000 + i * 56} y={720} t={t} s={0.6} />}
            </g>
          ) : null;
        })}
      </Frame>
      <Pill t0={98.6} t1={102} text="নিজের ছোট কাজের জায়গা" />
      <InfoCard w={CARD.phones6} x={960} y={330} rot={-3} />
    </>
  );
};

export const S6: React.FC = () => {
  const t = useT();
  // ফোনের অবস্থা: কিছুক্ষণ চালু, তারপর আবার কালো
  const on = (i: number): boolean => {
    if (i < 2) return false;
    const starts = [0, 0, 116.8, 120.7, 122.8, 124.7];
    if (t < starts[i]) return false;
    if (t >= 124.7) return Math.floor((t - 124.7) / 0.9 + i * 0.5) % 2 === 0;
    return t - starts[i] < 1.8;
  };
  const pos = [[560, 360], [960, 360], [1360, 360], [560, 720], [960, 720], [1360, 720]];
  const day = Math.floor((t - 116.8) / 1.8) % 2 === 0 ? '১' : '২';
  return (
    <>
      <Frame>
        <MoBg />
        {pos.map(([x, y], i) => {
          const a = Math.min(1.08, pop(t, 116.9 + i * 0.12, 0.35));
          const burnt = i < 2;
          const isOn = on(i);
          return (
            <g key={i} transform={`translate(${x},${y})`}>
              <Phone s={1.7 * a} state={burnt ? 'burnt' : isOn ? 'on' : 'dead'} />
              {!burnt && (isOn ? <Check x={70} y={-90} s={0.8 * a} /> : <Cross x={70} y={-90} s={0.8 * a} />)}
            </g>
          );
        })}
        <Calendar x={200} y={540} s={1.15 * Math.min(1.05, pop(t, 117.2))} label={day} top="দিন" />
        <Calendar x={1720} y={540} s={1.15 * Math.min(1.05, pop(t, 117.4))} label={day === '১' ? '২' : '১'} top="দিন" />
      </Frame>
      <InfoCard w={CARD.cycle} x={960} y={930} size={58} />
    </>
  );
};

export const S7: React.FC = () => {
  const t = useT();
  const dark = t < 128.9 ? 0 : t < 158.2 ? 0.68 : ramp(t, 158.2, 160.2, 0.68, 0);
  const lightsOn = t >= 158.2;
  const mval = (f1: number, f2: number) => (5 + (Math.sin(t * f1) + Math.sin(t * f2)) * 1.3).toFixed(2);
  const reading = t < 156 ? mval(9, 5.3) : mval(7, 11.1);
  const nExpr: Expr = t < 158.2 ? 'think' : t < 162.4 ? 'surprised' : 'happy';
  const bz = t >= 129 ? 1 : 0;
  return (
    <>
      <Frame>
        <Home lamp={t < 128.9 || lightsOn} />
        <Character id="niloy" cfg={NILOY} x={620} y={990} expr={nExpr} pose="hold" look={0.8} />
        <Character id="tithi" cfg={TITHI} x={1130} y={990} expr="neutral" pose={{l: 98, r: 7}} look={-1} />
        <BenchTable />
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const a = Math.min(1.1, pop(t, 141.3 + i * 0.7, 0.3));
          return a > 0 ? <Charger key={i} x={400 + i * 112} y={738} s={0.85 * a} /> : null;
        })}
        {t >= 147.9 && <Multimeter x={1110} y={725} s={0.62} value={reading} />}
        {t >= 152.3 && t < 156 && <g transform={`translate(560,${690})`} opacity={popio(t, 152.3, 156)}><Notebook s={0.9} r={-8} /></g>}
        {t >= 162.6 && <Solder x={900} y={770} s={0.7} />}
        {t >= 162.4 && <Charger x={760} y={738} s={0.85} />}
        <rect width={1920} height={1080} fill="#070b1a" opacity={dark} />
        {bz === 1 && t < 160 && <Torch x={905} y={680} s={0.9} beam={t < 158.2 ? 1 : ramp(t, 158.2, 160, 1, 0)} />}
        {win(t, 147.9, 158.2) && (
          <g transform={`translate(1580,450) scale(${Math.min(1.05, pop(t, 147.9)) * 2.1})`}>
            <Multimeter value={reading} />
          </g>
        )}
        {win(t, 158.4, 162.6) && <Bulb x={620} y={290} s={0.8 * Math.min(1.1, pop(t, 158.4))} />}
      </Frame>
      <Pill t0={129} t1={132.6} text="রাত · বিদ্যুৎ নেই" />
      <InfoCard w={CARD.root} x={960} y={150} size={52} color="#1f5a4d" />
    </>
  );
};
