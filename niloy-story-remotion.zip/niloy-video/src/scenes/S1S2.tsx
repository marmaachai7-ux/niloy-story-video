import React from 'react';
import {Frame, popio, ramp, useT, win, lerpPos} from '../kit/core';
import {Character, NILOY, KARIM, EX_TEA1, EX_TEA2, EX_CUST, Expr} from '../kit/Character';
import {Shop} from '../kit/bg';
import {Phone, Coin, Cup} from '../kit/icons';
import {Bubble, Pill} from '../kit/ui';
import {BUB} from '../data';

const NX = 1130; // নিলয়ের অবস্থান
const KX = 560; // করিম কাকার অবস্থান
const FY = 930;

const Screwdriver: React.FC = () => (
  <g transform="rotate(-20)">
    <rect x={-8} y={-10} width={16} height={46} rx={7} fill="#d9503f" stroke="#222" strokeWidth={3} />
    <rect x={-3} y={36} width={6} height={44} fill="#bbb" stroke="#222" strokeWidth={2.5} />
  </g>
);
const PhoneBag: React.FC = () => (
  <g>
    <rect x={-44} y={-72} width={88} height={144} rx={16} fill="#fff" opacity={0.45} stroke="#222" strokeWidth={2.5} />
    <Phone state="dead" s={0.95} />
  </g>
);

export const S1: React.FC = () => {
  const t = useT();
  const nExpr: Expr = t < 9 ? 'sad' : 'ashamed';
  const smirk = win(t, 9, 17) ? 'smirk' : 'neutral';
  return (
    <>
      <Frame fade={false} cam={{t0: 14.7, t1: 23, s0: 1, s1: 1.25, ox: NX, oy: 520}}>
        <Shop />
        <Character id="tea1" cfg={EX_TEA1} x={1480} y={580} scale={0.56} expr={smirk as Expr} front={<Cup s={1.1} />} pose="hold" />
        <Character id="tea22" cfg={EX_TEA2} x={1680} y={580} scale={0.56} expr={smirk as Expr} front={<Cup s={1.1} />} pose="hold" />
        <Character id="karim" cfg={KARIM} x={KX} y={FY} expr="angry" pose={t < 4 ? 'point' : 'crossed'} talk={[0.2, 3.4]} look={1} tremble={t < 3.4 ? 1.2 : 0} />
        <Character id="niloy" cfg={NILOY} x={NX} y={FY} expr={nExpr} pose="hold" look={-1} earRed={ramp(t, 20.5, 23, 0, 1)} tremble={t > 21 ? 2 : 0} front={<Phone state="cracked" s={1.15} />} />
        <g transform={`translate(1330,${420 - Math.sin(t * 4) * 8}) scale(${popio(t, 19, 22.4) * 1.5})`}><Coin /></g>
      </Frame>
      <Pill t0={0.3} t1={3.6} text="করিম কাকার মোবাইল সার্ভিস" />
      <Pill t0={4.1} t1={7.2} text="করিম কাকা" x={KX} y={300} center color="#b5473d" />
      <Pill t0={9.4} t1={12.4} text="নিলয়" x={NX} y={300} center color="#27456b" />
      <Bubble w={BUB.k1} x={KX} y={FY - 570} />
    </>
  );
};

export const S2: React.FC = () => {
  const t = useT();
  const stoolPhone = t >= 24.9 && t < 48.8;
  const la = t < 24.9 ? -25 : ramp(t, 24.9, 26, -25, 7);
  const ra =
    t < 24.9 ? -25 : t < 26 ? ramp(t, 24.9, 26, -25, 70) : t < 28.6 ? ramp(t, 26, 28.6, 70, 60) : t < 48 ? 60 : ramp(t, 48, 48.8, 60, 80);
  const custX = lerpPos(t, 47, 48.4, 2100, 1640);
  const kPose = win(t, 44.6, 46.3) ? 'wave' : win(t, 30.9, 36.3) ? 'point' : 'crossed';
  const nExpr: Expr = t < 36.4 ? 'ashamed' : t < 44.8 ? 'sad' : 'neutral';
  return (
    <>
      <Frame cam={{t0: 23, t1: 26.3, s0: 1.25, s1: 1, ox: NX, oy: 520}} shake={[[30.9, 32.2, 5]]}>
        <Shop />
        <Character id="tea1" cfg={EX_TEA1} x={1480} y={580} scale={0.56} expr="smirk" front={<Cup s={1.1} />} pose="hold" />
        <Character id="tea22" cfg={EX_TEA2} x={1680} y={580} scale={0.56} expr="smirk" front={<Cup s={1.1} />} pose="hold" />
        {/* ছোট টুল */}
        <g>
          <rect x={1260} y={690} width={230} height={24} rx={6} fill="#7a5a30" stroke="#222" strokeWidth={4} />
          <rect x={1280} y={714} width={20} height={216} fill="#5c4326" stroke="#222" strokeWidth={3} />
          <rect x={1450} y={714} width={20} height={216} fill="#5c4326" stroke="#222" strokeWidth={3} />
          {stoolPhone && <Phone x={1400} y={645} s={0.85} r={-70} state="cracked" />}
          {t >= 28.6 && <g transform="translate(1320,672) rotate(-80)"><Screwdriver /></g>}
        </g>
        <Character id="karim" cfg={KARIM} x={KX} y={FY} expr={t > 44.6 && t < 46.3 ? 'smirk' : 'angry'} pose={kPose} talk={[30.9, 36.2]} look={1} tremble={win(t, 30.9, 34) ? 1.6 : 0} />
        <Character
          id="niloy" cfg={NILOY} x={NX} y={FY} expr={nExpr} look={-1} earRed={ramp(t, 22.7, 24, 0.9, 1)}
          pose={{l: la, r: ra}} talk={[36.4, 44.7]} tremble={t > 28.6 && t < 31 ? 2.4 : 0}
          front={t < 24.9 ? <Phone state="cracked" s={1.15} /> : undefined}
          holdR={t < 28.6 ? <Screwdriver /> : t >= 48.8 && t < 49.7 ? <PhoneBag /> : undefined}
        />
        {t > 46.8 && (
          <Character id="cust" cfg={EX_CUST} x={custX} y={FY} pose={{l: t < 48.4 ? 7 : ramp(t, 48.4, 49.2, 7, 65), r: 7}} look={-1} expr="neutral" holdL={t >= 49.7 ? <PhoneBag /> : undefined} />
        )}
      </Frame>
      <Bubble w={BUB.k2} x={KX} y={FY - 570} />
      <Bubble w={BUB.n1} x={NX} y={FY - 570} max={900} />
      <Pill t0={47.2} t1={50} text="কাস্টমার" x={1640} y={300} center color="#b5473d" />
    </>
  );
};
