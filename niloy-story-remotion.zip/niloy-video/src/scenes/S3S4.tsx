import React from 'react';
import {Frame, popio, pop, ramp, useT, win, lerpPos} from '../kit/core';
import {Character, NILOY, TITHI, MA, Expr} from '../kit/Character';
import {Home} from '../kit/bg';
import {Plate, Notebook, TinBox, Note, Bowl, Cross} from '../kit/icons';
import {Bubble, Pill} from '../kit/ui';
import {BUB} from '../data';

const FY = 990;
const NX = 620;
const TX = 1000;

const Table: React.FC = () => (
  <g>
    <rect x={300} y={790} width={1000} height={30} rx={8} fill="#8a6238" stroke="#222" strokeWidth={4} />
    <rect x={330} y={820} width={940} height={170} fill="#6f4d2a" stroke="#222" strokeWidth={4} />
    <path d="M330 856 H1270" stroke="#5a3d20" strokeWidth={4} />
  </g>
);

export const S3: React.FC = () => {
  const t = useT();
  const tx = lerpPos(t, 64.3, 66, 1700, TX);
  const walking = t > 64.3 && t < 66;
  return (
    <>
      <Frame>
        <Home dark={ramp(t, 50.3, 54, 0.05, 0.22)} />
        <Character id="niloy" cfg={NILOY} x={NX} y={FY} expr="sad" pose="hold" look={0.2} sweat={false} />
        <Character id="tithi" cfg={TITHI} x={tx} y={FY} walk={walking} expr={t > 66 ? 'sad' : 'neutral'} pose="idle" talk={[66.6, 71.6]} look={-1} hideLegs={false} />
        <Table />
        <Plate x={470} y={782} s={1.2} steam={ramp(t, 52, 66, 1, 0.1)} />
        {t > 57.5 && (
          <g transform={`translate(${NX + 20},${735 - (1 - Math.min(1, pop(t, 57.5))) * -40}) scale(${0.95 * Math.min(1.1, pop(t, 57.5))})`}>
            <Notebook r={-6} />
          </g>
        )}
        {[60.4, 61.6, 62.8].map((a, i) => (
          <g key={a} transform={`translate(${NX + 90 + i * 34},${690 - i * 6}) scale(${pop(t, a, 0.3) * 0.7})`}><Cross /></g>
        ))}
      </Frame>
      <Pill t0={50.5} t1={54.2} text="সন্ধ্যা · টিনের চালের ঘর" />
      <Pill t0={64.8} t1={67} text="তিথি · ছোট বোন" x={TX} y={540} center color="#d1537f" />
      <Bubble w={BUB.t1} x={TX} y={FY - 485} max={700} />
      <Bubble w={BUB.t2} x={TX} y={FY - 485} max={700} />
    </>
  );
};

export const S4: React.FC = () => {
  const t = useT();
  // টিনের কৌটা: খাটের নিচ থেকে টেবিলে
  const bx = lerpPos(t, 73.6, 75.3, 1700, 760);
  const by = ramp(t, 73.6, 75.3, 950, 748);
  const lid = t < 79.7 ? 26 : ramp(t, 79.7, 81.5, 26, 0);
  const showBox = t >= 73.6;
  const mx = t < 83.2 ? lerpPos(t, 81.5, 83.2, 2000, 1650) : t < 85.6 ? 1650 : lerpPos(t, 85.6, 87.4, 1650, 1420);
  const mWalk = win(t, 81.5, 83.2) || win(t, 85.6, 87.4);
  const bowlInHand = t >= 85.6 && t < 88.2;
  const bowlOnTable = t >= 88.2;
  const mPose = t < 85.6 ? 'idle' : t < 88.2 ? 'reach' : 'idle';
  const nExpr: Expr = t > 90 ? 'happy' : 'sad';
  return (
    <>
      <Frame>
        <Home dark={0.22} />
        <Character id="niloy" cfg={NILOY} x={NX} y={FY} expr={nExpr} pose="hold" look={0.3} />
        <Character id="tithi" cfg={TITHI} x={TX} y={FY} expr="sad" pose="idle" look={-1} />
        <Table />
        <Plate x={470} y={782} s={1.2} steam={0.1} />
        {showBox && <TinBox x={bx} y={by} lift={lid} />}
        {[0, 1, 2].map((i) => {
          const a = popio(t, 77.4, 78.6) + popio(t, 78.7, 79.8);
          return a > 0 ? <g key={i} transform={`translate(${bx - 40 + i * 40},${by - 70 - i * 6}) scale(${Math.min(1, a) * 0.6})`}><Note /></g> : null;
        })}
        <Character id="ma" cfg={MA} x={mx} y={FY} flip walk={mWalk} expr={t > 88 ? 'happy' : 'neutral'} pose={mPose as any} talk={[89, 92.8]} look={1} holdR={bowlInHand ? <Bowl y={-30} s={0.9} steam={1} /> : undefined} />
        {bowlOnTable && <Bowl x={1180} y={800} s={1.0} steam={ramp(t, 88.2, 90, 1, 0.5)} />}
      </Frame>
      <Pill t0={82.2} t1={85.2} text="মা" x={1650} y={400} center color="#4f7a6a" />
      <Bubble w={BUB.m1} x={mx} y={FY - 590} max={760} />
    </>
  );
};
