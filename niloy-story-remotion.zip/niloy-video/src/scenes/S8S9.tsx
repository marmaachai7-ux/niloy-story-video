import React from 'react';
import {Frame, popio, pop, ramp, useT, win, lerpPos, FONT} from '../kit/core';
import {Character, NILOY2, KARIM, EX_TECH, EX_TEA2, EX_TEA1, EX_CUST, Expr} from '../kit/Character';
import {Shop, Street, Facade, MoBg} from '../kit/bg';
import {Phone, Charger, Check, Calendar, People, Arrow, ShopIcon, Cup, Key, Multimeter, Quote, Trophy, Note} from '../kit/icons';
import {Bubble, ThinkBubble, Pill, InfoCard, QuoteCard} from '../kit/ui';
import {BUB, CARD, CHANNEL_NAME} from '../data';

const Box: React.FC<{x: number; t0: number; children: React.ReactNode}> = ({x, t0, children}) => {
  const t = useT();
  const a = Math.min(1.06, pop(t, t0, 0.4));
  if (a <= 0) return null;
  return (
    <g transform={`translate(${x},470) scale(${a})`}>
      <rect x={-190} y={-170} width={380} height={340} rx={36} fill="rgba(255,255,255,0.12)" stroke="#fff" strokeOpacity={0.6} strokeWidth={5} />
      {children}
    </g>
  );
};

export const S8: React.FC = () => {
  const t = useT();
  const flowOp = 1 - ramp(t, 176.4, 176.9);
  const facadeOp = ramp(t, 180.2, 180.9);
  const swing = t > 180.9 ? Math.sin((t - 180.9) * 5) * 3 * Math.max(0, 1 - (t - 180.9) / 3) : 0;
  return (
    <>
      <Frame>
        <MoBg hue="navy" />
        <g opacity={flowOp}>
          <Box x={330} t0={164.8}><Charger y={-10} s={1.6} /><Check x={95} y={-95} s={1.0} /></Box>
          <g opacity={pop(t, 169.2, 0.3) > 0 ? 1 : 0}><Arrow x={540} y={470} len={110} /></g>
          <Box x={960} t0={169.6}><Calendar x={-50} y={-5} s={1.1} label="৭" top="দিন" /><Phone x={100} y={20} s={1.15} state="on" /></Box>
          <g opacity={pop(t, 174.6, 0.3) > 0 ? 1 : 0}><Arrow x={1170} y={470} len={110} /></g>
          <Box x={1590} t0={174.9}><People y={20} s={1.15} /></Box>
        </g>
        {win(t, 176.7, 180.4) && (
          <g transform={`translate(960,430) scale(${Math.min(1.05, pop(t, 176.7)) * 2.2})`}><Calendar label="২.৫" top="বছর" /></g>
        )}
        <g opacity={facadeOp}>
          <Facade swing={swing} />
          <Character id="niloy" cfg={NILOY2} x={1590} y={960} scale={0.95} expr="happy" pose="hold" />
          <Character id="tech1" cfg={EX_TECH} x={300} y={960} scale={0.9} expr="happy" pose="idle" />
        </g>
      </Frame>
      <InfoCard w={CARD.years} x={960} y={900} size={74} color="#1f5a4d" />
    </>
  );
};

export const S9a: React.FC = () => {
  const t = useT();
  const nx = t < 193 ? 1380 : lerpPos(t, 193, 196.4, 1380, 200);
  const tx = lerpPos(t, 189.5, 191.4, -250, 870);
  const handing = t >= 191.2 && t < 192.4;
  const nPose = t < 190.2 ? 'hold' : t < 192.4 ? ({l: ramp(t, 190.2, 191.2, 7, 75), r: 7} as const) : 'idle';
  return (
    <>
      <Frame>
        <Street />
        <Character id="teaman" cfg={EX_TEA2} x={1650} y={720} scale={0.55} hideLegs expr="neutral" pose="idle" />
        <Character id="tech" cfg={EX_TECH} x={tx} y={940} walk={t < 191.4} expr="neutral" pose={{l: 7, r: handing ? 75 : 7}} holdR={t >= 192.3 ? <Key s={0.8} /> : undefined} look={1} />
        <Character
          id="niloy" cfg={NILOY2} x={nx} y={940} walk={t >= 193} expr={t < 186 ? 'happy' : t < 190 ? 'think' : 'neutral'}
          pose={nPose as any} look={-0.6}
          front={t < 190.2 ? <Cup s={1.3} /> : undefined}
          holdL={t >= 191.2 && t < 192.3 ? <Key s={0.8} /> : undefined}
        />
      </Frame>
      <Pill t0={184.2} t1={187.4} text="চায়ের দোকান" />
      <Pill t0={190.4} t1={194} text="সেদিন বিকেলে" />
      <ThinkBubble t0={186.8} t1={190.2} x={nx} y={380}>
        <ShopIcon y={0} s={0.9} empty />
        <Arrow x={58} y={-30} len={50} color="#d9503f" r={90} />
      </ThinkBubble>
    </>
  );
};

const Counter: React.FC = () => (
  <g>
    <rect x={800} y={770} width={760} height={28} rx={8} fill="#8a6238" stroke="#222" strokeWidth={4} />
    <rect x={820} y={798} width={720} height={132} fill="#6f4d2a" stroke="#222" strokeWidth={4} />
  </g>
);

export const S9b: React.FC = () => {
  const t = useT();
  const nx = t < 204.3 ? lerpPos(t, 202, 204.3, -250, 640) : t < 214 ? 640 : lerpPos(t, 214, 215.4, 640, 700);
  const walking = win(t, 202, 204.3) || win(t, 214, 215.4);
  const hasMm = t >= 209.7;
  const mmOnNiloy = hasMm && t < 229.5;
  const mmOnKarim = t >= 229.5;
  const nPose = t < 209 ? 'idle' : t < 215.4 ? ({l: 7, r: 82} as const) : 'reach';
  const reading = (5 + (Math.sin(t * 9) + Math.sin(t * 5.3)) * 1.3).toFixed(2);
  const kL = t < 228.2 ? 7 : t < 229.5 ? ramp(t, 228.2, 229.5, 7, 82) : 82;
  const kR = win(t, 230.2, 231.9) ? -148 : 7;
  const kExpr: Expr = t < 224.5 ? 'sad' : t < 233.3 ? 'ashamed' : t < 236.2 ? 'surprised' : 'ashamed';
  const cam = {t0: 225.5, t1: 232, s0: 1, s1: 1.22, ox: 1000, oy: 600};
  return (
    <>
      <Frame cam={cam}>
        <Shop dim={0.35} shutter={300} tea={false} />
        <Character id="karim" cfg={KARIM} x={1250} y={930} expr={kExpr} look={-1} pose={{l: kL, r: kR}} talk={[[204.3, 206.7], [233.4, 236], [240.2, 242]]} holdL={mmOnKarim ? <Multimeter s={0.42} value={reading} /> : undefined} />
        <Counter />
        {t >= 198.6 && <Phone x={1030} y={732} s={0.7} state="dead" />}
        {t >= 201 && <Charger x={900} y={728} s={0.62} />}
        <Character id="niloy" cfg={NILOY2} x={nx} y={930} walk={walking} expr={t < 236 ? 'neutral' : 'think'} look={1} pose={nPose as any} talk={[[206.8, 208.8], [221.7, 224.8], [236.3, 240]]} holdR={mmOnNiloy ? <Multimeter s={0.42} value={t >= 211.7 && t < 215.4 ? reading : '0.00'} /> : undefined} />
        {win(t, 231.9, 242.5) && (
          <g transform={`translate(1640,500) scale(${Math.min(1.05, pop(t, 231.9)) * 1.6})`}><Multimeter value={reading} /></g>
        )}
      </Frame>
      <Pill t0={196.6} t1={200} text="করিম কাকার পুরনো দোকান" />
      <Bubble w={BUB.k3} x={1250} y={360} />
      <Bubble w={BUB.n2} x={640} y={360} />
      <Bubble w={BUB.n3} x={700} y={360} cam={cam} />
      <Bubble w={BUB.k4} x={1250} y={360} cam={cam} />
      <Bubble w={BUB.n4} x={700} y={360} cam={cam} />
      <Bubble w={BUB.k5} x={1250} y={360} cam={cam} />
    </>
  );
};

export const S9c: React.FC = () => {
  const t = useT();
  const nx = lerpPos(t, 242.5, 246.2, 700, -250);
  const mmInHand = t >= 248.5;
  const lL = t < 248 ? 7 : ramp(t, 248, 248.8, 7, 82);
  const reading = (5 + (Math.sin(t * 9) + Math.sin(t * 5.3)) * 1.3).toFixed(2);
  return (
    <>
      <Frame filter="sepia(0.75) saturate(0.8) brightness(0.95)">
        <Shop dim={0.1} />
        <Character id="karim" cfg={KARIM} x={1250} y={930} expr={t < 246 ? 'ashamed' : 'think'} look={-1} pose={{l: lL, r: 7}} holdL={mmInHand ? <Multimeter s={0.42} value={reading} /> : undefined} />
        <Counter />
        {t >= 246 && <Charger x={900} y={728} s={0.62} />}
        {t >= 244.2 && !mmInHand && <Multimeter x={1020} y={725} s={0.4} value="0.00" r={-12} />}
        <Character id="niloy" cfg={NILOY2} x={nx} y={930} walk expr="neutral" look={-1} pose="idle" />
      </Frame>
      <Pill t0={242.6} t1={246} text="সেদিন" />
      <Pill t0={246.4} t1={250.4} text="পরদিন সকালে" />
    </>
  );
};

export const S9d: React.FC = () => (
  <>
    <Frame>
      <MoBg />
      <QuoteMarks />
    </Frame>
    <QuoteCard w={CARD.q1} y={560} size={88} />
    <QuoteCard w={CARD.q2} y={600} size={70} />
  </>
);
const QuoteMarks: React.FC = () => {
  const t = useT();
  return (
    <g>
      {win(t, 250.7, 256.3) && <g transform={`translate(960,${250})`}><Quote s={Math.min(1.1, pop(t, 250.7))} /></g>}
      {t >= 258.4 && <g transform={`translate(960,230) scale(${Math.min(1.1, pop(t, 258.4, 0.5)) * 1.3})`}><Trophy /></g>}
    </g>
  );
};

export const S9e: React.FC = () => {
  const t = useT();
  const a = Math.min(1.05, pop(t, 262.0, 0.5));
  const b = Math.min(1.1, pop(t, 262.6, 0.4));
  return (
    <Frame>
      <MoBg />
      <g transform={`translate(960,560) scale(${a})`}>
        <rect x={-560} y={-210} width={1120} height={420} rx={36} fill="#17463d" stroke="#2f7d6d" strokeWidth={6} />
        <circle cy={-210} r={92} fill="#f2c230" stroke="#222" strokeWidth={5} />
        <text y={-180} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={96} fill="#222">নি</text>
        <text y={-30} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={84} fill="#fff">{CHANNEL_NAME}</text>
        <g transform={`translate(0,100) scale(${b})`}>
          <rect x={-250} y={-48} width={500} height={96} rx={48} fill="#f2c230" stroke="#222" strokeWidth={5} />
          <text y={22} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={56} fill="#222">+ সাবস্ক্রাইব</text>
        </g>
      </g>
    </Frame>
  );
};
