import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FPS, SCENES} from './data';
import {FONT, SceneProvider} from './kit/core';
import {Captions} from './kit/ui';
import {S1, S2} from './scenes/S1S2';
import {S3, S4} from './scenes/S3S4';
import {S5a, S5b, S6, S7} from './scenes/S5S6S7';
import {S8, S9a, S9b, S9c, S9d, S9e} from './scenes/S8S9';

const MAP: Record<string, React.FC> = {
  s1: S1, s2: S2, s3: S3, s4: S4, s5a: S5a, s5b: S5b, s6: S6, s7: S7,
  s8: S8, s9a: S9a, s9b: S9b, s9c: S9c, s9d: S9d, s9e: S9e,
};
const OVERLAP = 8; // ফ্রেম — পরের সিনের ফেড-ইন পুরনো সিনের ওপর

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000', fontFamily: FONT}}>
    <Audio src={staticFile('voice.mp3')} volume={1} />
    {SCENES.map((s, i) => {
      const Comp = MAP[s.id];
      const from = Math.round(s.from * FPS);
      const end = Math.round(s.to * FPS);
      const dur = end - from + (i < SCENES.length - 1 ? OVERLAP : 0);
      return (
        <Sequence key={s.id} from={from} durationInFrames={dur}>
          <SceneProvider value={from / FPS}>
            <Comp />
          </SceneProvider>
        </Sequence>
      );
    })}
    <Captions />
  </AbsoluteFill>
);
