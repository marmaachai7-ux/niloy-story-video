import React from 'react';
import {FONT, Cam, applyCam, popio, pop, ramp, useT} from './core';
import {CUES, HIDE, Win} from '../data';

const KEY = /(multimeter|charger|soldering|screwdriver|track|torch|reading|customer|sign|নিলয়|করিম|তিথি|বেতন|ভুল|খাতা|কৌটা|ছয়টা|আড়াই|সাত|লাফাচ্ছে|সম্মান|জয়|চাবি|ট্র্যাক|টেক|কেয়ার)/i;

/** নিচের ভাসমান ক্যাপশন — কলআউট/কার্ড থাকলে লুকানো */
export const Captions: React.FC = () => {
  const t = useT();
  if (HIDE.some(([a, b]) => t >= a && t < b)) return null;
  const cue = CUES.find(([a, b]) => t >= a && t < b + 0.05);
  if (!cue) return null;
  const [a, , text] = cue;
  const p = pop(t, a, 0.25);
  const words = text.split(' ');
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 70, display: 'flex', justifyContent: 'center', opacity: Math.min(1, p * 1.4), transform: `translateY(${(1 - Math.min(1, p)) * 24}px)`}}>
      <div style={{background: 'rgba(18,18,18,0.82)', borderRadius: 18, padding: '12px 36px', fontFamily: FONT, fontWeight: 600, fontSize: 52, color: '#fff', whiteSpace: 'nowrap', border: '2px solid rgba(255,255,255,0.12)'}}>
        {words.map((w, i) => (
          <span key={i} style={KEY.test(w) ? {color: '#ffc83d', fontWeight: 700} : undefined}>{w}{i < words.length - 1 ? ' ' : ''}</span>
        ))}
      </div>
    </div>
  );
};

/** স্পিচ কলআউট বাবল — (x,y) হলো বক্তার মাথার ঠিক ওপরের বিন্দু */
export const Bubble: React.FC<{w: Win; x: number; y: number; cam?: Cam; max?: number}> = ({w, x, y, cam, max = 820}) => {
  const t = useT();
  if (t < w.t0 || t > w.t1 + 0.1) return null;
  const s = popio(t, w.t0, w.t1);
  const [ax, ay] = applyCam(x, y, cam, t);
  const half = max / 2 + 30;
  const cx = Math.min(1920 - half, Math.max(half, ax));
  const off = ax - cx;
  return (
    <div style={{position: 'absolute', left: cx, top: ay - 24, transform: `translate(-50%,-100%) scale(${s})`, transformOrigin: `${50 + (off / max) * 100}% 100%`, maxWidth: max, width: 'max-content'}}>
      <div style={{background: '#fff', border: '4px solid #222', borderRadius: 30, padding: '16px 30px', fontFamily: FONT, fontWeight: 700, fontSize: 50, lineHeight: 1.25, color: '#1c1c1c', textAlign: 'center', boxShadow: '0 6px 0 rgba(0,0,0,0.18)'}}>{w.text}</div>
      <div style={{position: 'absolute', left: `calc(50% + ${Math.max(-max / 2 + 50, Math.min(max / 2 - 50, off))}px)`, bottom: -22, width: 34, height: 34, background: '#fff', borderRight: '4px solid #222', borderBottom: '4px solid #222', transform: 'translateX(-50%) rotate(45deg)'}} />
    </div>
  );
};

/** থট বাবল — ভেতরে আইকন (SVG children) */
export const ThinkBubble: React.FC<{t0: number; t1: number; x: number; y: number; w?: number; h?: number; children: React.ReactNode}> = ({t0, t1, x, y, w = 280, h = 200, children}) => {
  const t = useT();
  if (t < t0 || t > t1 + 0.1) return null;
  const s = popio(t, t0, t1);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-100%) scale(${s})`, transformOrigin: '50% 100%'}}>
      <svg width={w} height={h + 70} viewBox={`0 0 ${w} ${h + 70}`} style={{overflow: 'visible'}}>
        <ellipse cx={w / 2} cy={h / 2} rx={w / 2 - 4} ry={h / 2 - 4} fill="#fff" stroke="#222" strokeWidth={4} />
        <circle cx={w / 2 - 20} cy={h + 20} r={14} fill="#fff" stroke="#222" strokeWidth={4} />
        <circle cx={w / 2 - 34} cy={h + 54} r={8} fill="#fff" stroke="#222" strokeWidth={4} />
        <g transform={`translate(${w / 2},${h / 2})`}>{children}</g>
      </svg>
    </div>
  );
};

/** ওপরের লোকেশন/সময়/নাম পিল-ব্যাজ */
export const Pill: React.FC<{t0: number; t1: number; text: string; x?: number; y?: number; color?: string; center?: boolean}> = ({t0, t1, text, x = 48, y = 44, color = '#1f6b5c', center}) => {
  const t = useT();
  if (t < t0 || t > t1 + 0.1) return null;
  const s = popio(t, t0, t1);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `${center ? 'translateX(-50%) ' : ''}scale(${s})`, transformOrigin: center ? '50% 50%' : '0 50%', background: color, color: '#fff', fontFamily: FONT, fontWeight: 700, fontSize: 38, padding: '8px 30px', borderRadius: 999, border: '3px solid #222', boxShadow: '0 5px 0 rgba(0,0,0,0.2)', whiteSpace: 'nowrap'}}>{text}</div>
  );
};

/** ইনফো কার্ড / স্ট্যাম্প */
export const InfoCard: React.FC<{w: Win; x: number; y: number; rot?: number; stamp?: boolean; size?: number; color?: string}> = ({w, x, y, rot = 0, stamp, size = 54, color}) => {
  const t = useT();
  if (t < w.t0 || t > w.t1 + 0.1) return null;
  const s = popio(t, w.t0, w.t1);
  const style: React.CSSProperties = stamp
    ? {color: color ?? '#c92f2f', border: `8px solid ${color ?? '#c92f2f'}`, background: 'rgba(255,255,255,0.88)', borderRadius: 14, fontSize: size + 10, letterSpacing: 1}
    : {color: '#fff', background: color ?? '#1f5a4d', border: '4px solid #222', borderRadius: 18, fontSize: size, boxShadow: '0 7px 0 rgba(0,0,0,0.25)'};
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`, fontFamily: FONT, fontWeight: 700, padding: '14px 40px', textAlign: 'center', maxWidth: 1300, ...style}}>{w.text}</div>
  );
};

/** বড় কোটেশন কার্ড (মোশন গ্রাফিক্স দৃশ্য) */
export const QuoteCard: React.FC<{w: Win; y?: number; size?: number}> = ({w, y = 540, size = 78}) => {
  const t = useT();
  if (t < w.t0 || t > w.t1 + 0.1) return null;
  const s = popio(t, w.t0, w.t1);
  return (
    <div style={{position: 'absolute', left: 160, right: 160, top: y, transform: `translateY(-50%) scale(${0.9 + 0.1 * Math.min(1, s)})`, opacity: Math.min(1, s), textAlign: 'center', fontFamily: FONT, fontWeight: 700, fontSize: size, lineHeight: 1.35, color: '#fff', textShadow: '0 4px 0 rgba(0,0,0,0.35)'}}>{w.text}</div>
  );
};
export {ramp};
