import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FPS} from '../data';
import {useT} from './core';

const O = '#222222';
const SW = 3.5;

export type CharCfg = {
  skin: string;
  hair: string;
  hairStyle: 'short' | 'braids' | 'covered' | 'bald';
  shirt: string;
  pattern?: 'check' | 'polo' | 'none';
  pants: string;
  bottom?: 'pants' | 'lungi' | 'saree';
  glasses?: boolean;
  moustache?: boolean;
  lanyard?: boolean;
  pocket?: boolean;
  accent?: string; // ওড়না / পাড় / আইডি রঙ
  scale?: number;
};

export type Expr = 'neutral' | 'angry' | 'sad' | 'happy' | 'surprised' | 'think' | 'ashamed' | 'tired' | 'smirk';
export type PoseName = 'idle' | 'point' | 'hold' | 'crossed' | 'up' | 'wave' | 'face' | 'reach';
export type Pose = PoseName | {l: number; r: number};

const POSES: Record<PoseName, {l: number; r: number}> = {
  idle: {l: 7, r: 7},
  point: {l: 7, r: 100},
  reach: {l: 7, r: 80},
  hold: {l: -25, r: -25},
  crossed: {l: -42, r: -42},
  up: {l: 150, r: 150},
  wave: {l: 7, r: 125},
  face: {l: 7, r: -148},
};

// চরিত্র প্রিসেট
export const NILOY: CharCfg = {skin: '#c68b59', hair: '#1b1b1b', hairStyle: 'short', shirt: '#e0a82e', pattern: 'check', pants: '#cdb98a', pocket: true};
export const NILOY2: CharCfg = {skin: '#c68b59', hair: '#1b1b1b', hairStyle: 'short', shirt: '#27456b', pattern: 'polo', pants: '#3b3b4a', lanyard: true, accent: '#e8e8e8'};
export const KARIM: CharCfg = {skin: '#b9825a', hair: '#555555', hairStyle: 'short', shirt: '#8a8f96', pants: '#2f6b5e', bottom: 'lungi', glasses: true, moustache: true, pocket: true};
export const TITHI: CharCfg = {skin: '#c99060', hair: '#1b1b1b', hairStyle: 'braids', shirt: '#e07a9b', pants: '#5a4a7a', accent: '#f4d6e0', scale: 0.86};
export const MA: CharCfg = {skin: '#bf8657', hair: '#2a2a2a', hairStyle: 'covered', shirt: '#4f7a6a', pants: '#4f7a6a', bottom: 'saree', accent: '#d9b24c'};
export const EX_TEA1: CharCfg = {skin: '#b57c50', hair: '#222', hairStyle: 'short', shirt: '#e9e2cf', pants: '#6b7a8f', pocket: true};
export const EX_TEA2: CharCfg = {skin: '#c58f62', hair: '#333', hairStyle: 'bald', shirt: '#5b7f95', pants: '#3a3a3a', moustache: true};
export const EX_CUST: CharCfg = {skin: '#c28a5c', hair: '#222', hairStyle: 'short', shirt: '#b5473d', pants: '#2d3a55'};
export const EX_TECH: CharCfg = {skin: '#bd8559', hair: '#1b1b1b', hairStyle: 'short', shirt: '#27456b', pattern: 'polo', pants: '#3b3b4a', lanyard: true, accent: '#e8e8e8'};

const EXPR: Record<Expr, {by: number; bt: number; eye: number; blush: number; mouth: string}> = {
  neutral: {by: 0, bt: 0, eye: 1, blush: 0, mouth: 'M-15 -437 Q0 -435 15 -437'},
  angry: {by: 4, bt: 20, eye: 0.8, blush: 0.15, mouth: 'M-18 -431 Q0 -443 18 -431'},
  sad: {by: -2, bt: -16, eye: 0.9, blush: 0, mouth: 'M-14 -430 Q0 -441 14 -430'},
  ashamed: {by: 0, bt: -12, eye: 0.7, blush: 0.35, mouth: 'M-12 -432 Q0 -438 12 -432'},
  happy: {by: -6, bt: -4, eye: 0.85, blush: 0.2, mouth: 'M-20 -441 Q0 -418 20 -441 Z'},
  surprised: {by: -14, bt: 0, eye: 1.15, blush: 0, mouth: 'O'},
  think: {by: -3, bt: 8, eye: 0.95, blush: 0, mouth: 'M-11 -436 L12 -432'},
  tired: {by: 3, bt: -6, eye: 0.5, blush: 0, mouth: 'M-12 -434 Q0 -437 12 -434'},
  smirk: {by: -2, bt: 6, eye: 0.85, blush: 0.1, mouth: 'M-14 -438 Q8 -430 18 -444'},
};

export type CharProps = {
  cfg: CharCfg;
  x: number;
  y: number;
  expr?: Expr;
  pose?: Pose;
  talk?: [number, number] | [number, number][];
  flip?: boolean;
  walk?: boolean;
  look?: number; // -1..1
  tremble?: number;
  earRed?: number; // 0..1
  tears?: boolean;
  sweat?: boolean;
  scale?: number;
  holdR?: React.ReactNode; // ডান হাতে জিনিস (হাতের সাথে যুক্ত)
  holdL?: React.ReactNode;
  front?: React.ReactNode; // শরীরের সামনে (দুই হাতের মাঝে)
  id?: string;
  hideLegs?: boolean;
};

const Arm: React.FC<{side: 1 | -1; a: number; cfg: CharCfg; hold?: React.ReactNode}> = ({side, a, cfg, hold}) => {
  // side=-1 → স্ক্রিনের বাম কাঁধ
  const sx = side * 75;
  const rot = side === -1 ? a : -a;
  return (
    <g transform={`translate(${sx},-350) rotate(${rot})`}>
      <rect x={-17} y={0} width={34} height={178} rx={17} fill={cfg.skin} stroke={O} strokeWidth={SW} />
      <rect x={-18} y={-4} width={36} height={cfg.bottom === 'saree' ? 120 : 96} rx={17} fill={cfg.shirt} stroke={O} strokeWidth={SW} />
      <circle cx={0} cy={188} r={21} fill={cfg.skin} stroke={O} strokeWidth={SW} />
      {hold && <g transform="translate(0,190)">{hold}</g>}
    </g>
  );
};

export const Character: React.FC<CharProps> = ({
  cfg, x, y, expr = 'neutral', pose = 'idle', talk, flip, walk, look = 0, tremble = 0, earRed = 0, tears, sweat,
  scale, holdR, holdL, front, id = 'c', hideLegs,
}) => {
  const f = useCurrentFrame();
  const t = useT();
  const sc = (scale ?? cfg.scale ?? 1) * 1;
  const e = EXPR[expr];

  // কথা বলা: ৩টি সহজ মুখের আকার
  const ranges: [number, number][] = !talk ? [] : Array.isArray(talk[0]) ? (talk as [number, number][]) : [talk as [number, number]];
  const talking = ranges.some(([a, b]) => t >= a && t < b);
  const shape = [0, 1, 2, 1, 2, 0, 1][Math.floor(t * 9) % 7];

  // পলক
  const bp = (f + id.length * 23) % 96;
  const blink = bp < 4;
  const eyeY = blink ? 0.08 : e.eye;

  // ভাসা, হাঁটা ও কাঁপুনি
  const ph = id.length * 1.3;
  const float = walk ? Math.abs(Math.sin((f / FPS) * Math.PI * 4.4)) * -10 : Math.sin((f / FPS) * Math.PI + ph) * 4;
  const trx = tremble ? Math.sin(f * 3.9) * tremble : 0;
  const stride = walk ? Math.sin((f / FPS) * Math.PI * 4.4) * 24 : 0;

  const base = typeof pose === 'string' ? POSES[pose] : pose;
  const sway = Math.sin((f / FPS) * 2 + ph) * 2.5;
  let la = base.l + sway - stride * 0.7;
  let ra = base.r - sway + stride * 0.7;
  if (pose === 'wave') ra = 125 + Math.sin((f / FPS) * 14) * 18;
  if (tremble) {
    la += Math.sin(f * 4.4) * tremble * 1.5;
    ra += Math.cos(f * 4.1) * tremble * 1.5;
  }

  const pid = `${id}-chk`;
  const tr = `translate(${x + trx},${y + float}) scale(${flip ? -sc : sc},${sc})`;
  const legShift = walk ? stride : 0;

  const torsoH = 250;
  return (
    <g transform={tr}>
      <ellipse cx={0} cy={4} rx={105} ry={14} fill="rgba(0,0,0,0.18)" transform={`translate(0,${-float / sc})`} />
      <defs>
        <pattern id={pid} width={26} height={26} patternUnits="userSpaceOnUse">
          <rect width={26} height={26} fill="none" />
          <path d="M0 13H26M13 0V26" stroke="rgba(0,0,0,0.16)" strokeWidth={5} />
        </pattern>
      </defs>

      {/* পিছনের চুল / ঘোমটা / বেণী */}
      {cfg.hairStyle === 'covered' && (
        <path d="M-84 -455 C-92 -575 92 -575 84 -455 L98 -350 L-98 -350 Z" fill={cfg.shirt} stroke={O} strokeWidth={SW} />
      )}
      {cfg.hairStyle === 'braids' &&
        [-1, 1].map((s) => (
          <g key={s} transform={`translate(${s * 86},-445) rotate(${-s * 6})`}>
            <rect x={-13} y={0} width={26} height={120} rx={13} fill={cfg.hair} stroke={O} strokeWidth={SW} />
            <circle cx={0} cy={118} r={9} fill="#f4a3c0" stroke={O} strokeWidth={2.5} />
          </g>
        ))}

      {/* পা / নিচের পোশাক */}
      {!hideLegs && cfg.bottom !== 'saree' && cfg.bottom !== 'lungi' &&
        [-1, 1].map((s) => (
          <g key={s} transform={`translate(${s * 30},-175) rotate(${s * legShift})`}>
            <rect x={-21} y={0} width={42} height={166} rx={19} fill={cfg.pants} stroke={O} strokeWidth={SW} />
            <ellipse cx={4} cy={168} rx={32} ry={13} fill="#4a3426" stroke={O} strokeWidth={SW} />
          </g>
        ))}
      {!hideLegs && cfg.bottom === 'lungi' && (
        <g>
          {[-1, 1].map((s) => (
            <ellipse key={s} cx={s * 32 + (s * legShift) / 3} cy={-8} rx={32} ry={13} fill="#4a3426" stroke={O} strokeWidth={SW} />
          ))}
          <path d="M-88 -200 L88 -200 L100 -30 L-100 -30 Z" fill={cfg.pants} stroke={O} strokeWidth={SW} />
          <path d="M-88 -200 L88 -200 L100 -30 L-100 -30 Z" fill={`url(#${pid})`} />
          <rect x={-100} y={-44} width={200} height={14} fill="#e9dfb8" opacity={0.7} />
        </g>
      )}
      {!hideLegs && cfg.bottom === 'saree' && (
        <g>
          {[-1, 1].map((s) => (
            <ellipse key={s} cx={s * 30} cy={-6} rx={30} ry={12} fill="#4a3426" stroke={O} strokeWidth={SW} />
          ))}
          <path d="M-92 -210 L92 -210 L112 -24 L-112 -24 Z" fill={cfg.shirt} stroke={O} strokeWidth={SW} />
          <path d="M-110 -40 L110 -40 L112 -24 L-112 -24 Z" fill={cfg.accent} stroke={O} strokeWidth={2.5} />
        </g>
      )}

      {/* দুই হাত (পিছনে) */}
      <Arm side={-1} a={la} cfg={cfg} hold={holdL} />

      {/* শরীর */}
      <rect x={-78} y={-385} width={156} height={torsoH} rx={44} fill={cfg.shirt} stroke={O} strokeWidth={SW} />
      {cfg.pattern === 'check' && <rect x={-78} y={-385} width={156} height={torsoH} rx={44} fill={`url(#${pid})`} />}
      {cfg.pocket && <rect x={22} y={-320} width={36} height={40} rx={5} fill="none" stroke={O} strokeWidth={3} />}
      {cfg.pattern === 'polo' && (
        <g>
          <path d="M-30 -385 L0 -335 L30 -385 Z" fill="#f2f2f2" stroke={O} strokeWidth={3} />
          <path d="M0 -335 L0 -290" stroke={O} strokeWidth={3} />
          <circle cx={0} cy={-312} r={3.5} fill={O} />
          <circle cx={0} cy={-296} r={3.5} fill={O} />
        </g>
      )}
      {cfg.lanyard && (
        <g>
          <path d="M-22 -385 L-4 -250 M22 -385 L4 -250" stroke="#d63c3c" strokeWidth={5} />
          <rect x={-22} y={-256} width={44} height={58} rx={6} fill="#fff" stroke={O} strokeWidth={3} />
          <circle cx={0} cy={-236} r={9} fill="#c68b59" stroke={O} strokeWidth={2} />
          <rect x={-14} y={-220} width={28} height={5} fill="#27456b" />
        </g>
      )}
      {cfg.hairStyle === 'braids' && cfg.accent && (
        <path d="M-78 -330 L-40 -385 L-10 -385 L78 -190 L40 -150 Z" fill={cfg.accent} opacity={0.9} stroke={O} strokeWidth={3} />
      )}
      {cfg.bottom === 'saree' && cfg.accent && (
        <path d="M-60 -385 L-12 -385 L78 -230 L40 -190 Z" fill={cfg.accent} opacity={0.85} stroke={O} strokeWidth={3} />
      )}

      {/* ঘাড় */}
      <rect x={-17} y={-410} width={34} height={36} fill={cfg.skin} stroke={O} strokeWidth={SW} />

      {/* কান */}
      {[-1, 1].map((s) => (
        <g key={s}>
          <ellipse cx={s * 69} cy={-466} rx={12} ry={17} fill={cfg.skin} stroke={O} strokeWidth={SW} />
          {earRed > 0 && <ellipse cx={s * 69} cy={-466} rx={10} ry={15} fill="#e0392f" opacity={earRed * 0.85} />}
        </g>
      ))}
      {/* মাথা */}
      <ellipse cx={0} cy={-470} rx={68} ry={78} fill={cfg.skin} stroke={O} strokeWidth={SW} />

      {/* চুল (সামনে) */}
      {(cfg.hairStyle === 'short' || cfg.hairStyle === 'braids') && (
        <path d="M-70 -468 C-80 -568 80 -568 70 -468 C64 -508 40 -520 0 -510 C-40 -520 -64 -508 -70 -468 Z" fill={cfg.hair} stroke={O} strokeWidth={SW} />
      )}
      {cfg.hairStyle === 'covered' && (
        <path d="M-66 -478 C-60 -540 60 -540 66 -478 C40 -512 -40 -512 -66 -478 Z" fill="#2a2a2a" stroke={O} strokeWidth={SW} />
      )}

      {/* গাল */}
      {[-1, 1].map((s) => (
        <circle key={s} cx={s * 42} cy={-446} r={14} fill="#e0715e" opacity={0.22 + e.blush + earRed * 0.3} />
      ))}
      {/* চোখ */}
      {[-1, 1].map((s) => (
        <g key={s}>
          <ellipse cx={s * 27} cy={-480} rx={15} ry={17 * eyeY + 0.5} fill="#fff" stroke={O} strokeWidth={3} />
          {eyeY > 0.2 && <circle cx={s * 27 + look * 5} cy={-480 + (expr === 'sad' || expr === 'ashamed' ? 3 : 0)} r={7.5 * Math.min(1, eyeY + 0.2)} fill={O} />}
          {expr === 'tired' && <path d={`M${s * 27 - 16} -492 L${s * 27 + 16} -492`} stroke={O} strokeWidth={4} />}
          <g transform={`translate(${s * 27},${-508 + e.by}) rotate(${s === -1 ? e.bt : -e.bt})`}>
            <rect x={-16} y={-3.5} width={32} height={7} rx={3.5} fill={cfg.hairStyle === 'bald' ? '#2a2a2a' : cfg.hair === '#555555' ? '#3a3a3a' : cfg.hair} />
          </g>
        </g>
      ))}
      {cfg.glasses && (
        <g fill="rgba(200,230,255,0.22)" stroke={O} strokeWidth={4}>
          <circle cx={-27} cy={-480} r={23} />
          <circle cx={27} cy={-480} r={23} />
          <path d="M-4 -482 L4 -482" fill="none" />
        </g>
      )}
      {/* নাক */}
      <path d="M0 -472 Q-7 -454 5 -453" fill="none" stroke={O} strokeWidth={3} strokeLinecap="round" />
      {cfg.moustache && (
        <path d="M-26 -450 Q-13 -464 0 -453 Q13 -464 26 -450 Q13 -444 0 -449 Q-13 -444 -26 -450Z" fill="#2a2a2a" stroke={O} strokeWidth={2} />
      )}
      {/* মুখ */}
      {talking ? (
        <ellipse cx={0} cy={-436} rx={shape === 2 ? 15 : 12} ry={shape === 0 ? 3 : shape === 1 ? 7 : 13} fill="#6b2430" stroke={O} strokeWidth={3} />
      ) : e.mouth === 'O' ? (
        <ellipse cx={0} cy={-434} rx={10} ry={13} fill="#6b2430" stroke={O} strokeWidth={3} />
      ) : expr === 'happy' ? (
        <path d={e.mouth} fill="#7a2e2e" stroke={O} strokeWidth={3} strokeLinejoin="round" />
      ) : (
        <path d={e.mouth} fill="none" stroke={O} strokeWidth={4} strokeLinecap="round" />
      )}
      {tears &&
        [-1, 1].map((s) => (
          <ellipse key={s} cx={s * 30} cy={-455 + ((f * 3 + s * 20) % 40)} rx={5} ry={8} fill="#6ec1f0" stroke={O} strokeWidth={2} />
        ))}
      {sweat && <path d={`M62 ${-520 + Math.sin(f / 6) * 4} q10 16 0 24 q-10 -8 0 -24Z`} fill="#8fd3ff" stroke={O} strokeWidth={2.5} />}

      {/* দুই হাত (সামনে) */}
      <Arm side={1} a={ra} cfg={cfg} hold={holdR} />
      {front && <g transform="translate(0,-195)">{front}</g>}
    </g>
  );
};
