import React from 'react';
import {FONT} from './core';
import {Cup} from './icons';

const O = '#222';
const W = 1920;
const H = 1080;

/** করিম কাকার দোকান — ফ্লোর y≈930 */
export const Shop: React.FC<{dim?: number; shutter?: number; tea?: boolean}> = ({dim = 0, shutter = 0, tea = true}) => (
  <g>
    <defs>
      <linearGradient id="shopWall" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#f3e3bd" /><stop offset="1" stopColor="#e6cf9c" />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill="url(#shopWall)" />
    <rect y={650} width={W} height={150} fill="#b45a47" opacity={0.85} />
    <rect y={650} width={W} height={8} fill="#8a3f31" />
    <rect y={800} width={W} height={280} fill="#c9a77c" />
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <path key={i} d={`M${i * 260} 800 L${i * 260 - 120} 1080`} stroke="#b08e63" strokeWidth={4} />)}
    {/* তাকে ফোনের বাক্স */}
    <rect x={80} y={120} width={560} height={14} fill="#7a5a30" stroke={O} strokeWidth={3} />
    {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={100 + i * 106} y={64} width={80} height={56} rx={4} fill={['#4f86c6', '#d98a3a', '#5aa56f', '#c0564a', '#8a6fc0'][i]} stroke={O} strokeWidth={3} />)}
    <rect x={80} y={300} width={560} height={14} fill="#7a5a30" stroke={O} strokeWidth={3} />
    {[0, 1, 2, 3].map((i) => <rect key={i} x={110 + i * 130} y={236} width={100} height={64} rx={4} fill={['#d9c9a3', '#6fb3b8', '#c8a0d0', '#e0c050'][i]} stroke={O} strokeWidth={3} />)}
    {/* দেয়ালের সাইনবোর্ড */}
    <rect x={760} y={80} width={420} height={96} rx={12} fill="#2f6b5e" stroke={O} strokeWidth={4} />
    <text x={970} y={146} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={52} fill="#fff">মোবাইল সার্ভিস</text>
    {/* ঘড়ি */}
    <circle cx={970} cy={300} r={52} fill="#fff" stroke={O} strokeWidth={4} />
    <path d="M970 300 V268 M970 300 L992 312" stroke={O} strokeWidth={5} strokeLinecap="round" />
    {/* জানালা + চায়ের দোকান */}
    <rect x={1330} y={110} width={470} height={470} rx={10} fill="#bfe3f2" stroke={O} strokeWidth={6} />
    {tea && (
      <g>
        <rect x={1336} y={420} width={458} height={154} fill="#a9b7a0" />
        <path d="M1350 250 H1780 L1760 300 H1370Z" fill="#d9503f" stroke={O} strokeWidth={3} />
        <rect x={1390} y={330} width={350} height={20} fill="#7a5a30" stroke={O} strokeWidth={3} />
        <ellipse cx={1450} cy={316} rx={30} ry={20} fill="#999" stroke={O} strokeWidth={3} />
        <Cup x={1560} y={316} s={0.6} /><Cup x={1620} y={316} s={0.6} /><Cup x={1680} y={316} s={0.6} />
      </g>
    )}
    <path d="M1565 110 V580 M1330 345 H1800" stroke={O} strokeWidth={6} />
    {shutter > 0 && (
      <g>
        <rect width={W} height={shutter} fill="#8e969c" />
        {Array.from({length: Math.ceil(shutter / 34)}).map((_, i) => <path key={i} d={`M0 ${i * 34} H${W}`} stroke="#6f777d" strokeWidth={4} />)}
        <rect y={shutter - 12} width={W} height={14} fill="#5c6368" stroke={O} strokeWidth={3} />
      </g>
    )}
    {dim > 0 && <rect width={W} height={H} fill="#1a1a2e" opacity={dim} />}
  </g>
);

/** টিনের চালের ঘর — ফ্লোর y≈960 */
export const Home: React.FC<{dark?: number; lamp?: boolean}> = ({dark = 0, lamp = true}) => (
  <g>
    <rect width={W} height={H} fill="#d9b985" />
    <rect y={140} width={W} height={700} fill="#cfa974" />
    {/* টিনের চাল */}
    <rect width={W} height={150} fill="#8c9aa6" stroke={O} strokeWidth={4} />
    {Array.from({length: 64}).map((_, i) => <path key={i} d={`M${i * 30} 0 V150`} stroke="#6d7b87" strokeWidth={5} />)}
    <path d="M0 150 L0 190 L1920 190 L1920 150Z" fill="#6a4a30" stroke={O} strokeWidth={3} />
    {/* জানালা */}
    <rect x={120} y={260} width={260} height={330} rx={8} fill="#2a3a66" stroke={O} strokeWidth={6} />
    <circle cx={290} cy={340} r={30} fill="#f6f0c8" />
    {[[180, 400], [230, 470], [320, 430], [200, 540]].map(([a, b], i) => <circle key={i} cx={a} cy={b} r={4} fill="#fff" />)}
    <path d="M250 260 V590 M120 425 H380" stroke={O} strokeWidth={6} />
    {/* খাট */}
    <rect x={1380} y={640} width={520} height={46} rx={10} fill="#7a5a30" stroke={O} strokeWidth={4} />
    <rect x={1400} y={686} width={22} height={300} fill="#5c4326" stroke={O} strokeWidth={3} />
    <rect x={1860} y={686} width={22} height={300} fill="#5c4326" stroke={O} strokeWidth={3} />
    <rect x={1380} y={590} width={520} height={52} rx={14} fill="#c0564a" stroke={O} strokeWidth={4} />
    {/* ফ্লোর */}
    <rect y={960} width={W} height={120} fill="#9c7b57" />
    <rect y={956} width={W} height={8} fill="#7c5f40" />
    {/* ঝুলন্ত বাল্ব */}
    {lamp && (
      <g>
        <path d="M960 190 V300" stroke={O} strokeWidth={4} />
        <circle cx={960} cy={320} r={22} fill="#ffe27a" stroke={O} strokeWidth={4} />
        <circle cx={960} cy={320} r={90} fill="#ffe27a" opacity={0.16} />
      </g>
    )}
    {dark > 0 && <rect width={W} height={H} fill="#070b1a" opacity={dark} />}
  </g>
);

/** রাস্তা + চায়ের স্টল — ফ্লোর y≈940 */
export const Street: React.FC<{sunset?: boolean}> = ({sunset}) => (
  <g>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={sunset ? '#f4a96b' : '#8fd0ec'} /><stop offset="1" stopColor={sunset ? '#f8d9a0' : '#e8f6fb'} />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill="url(#sky)" />
    {[0, 1, 2, 3, 4, 5, 6].map((i) => (
      <rect key={i} x={i * 290 - 30} y={210 + (i % 3) * 50} width={250} height={440 - (i % 3) * 50} fill={['#c9b9a3', '#a9b7c6', '#d8bfa0'][i % 3]} stroke={O} strokeWidth={4} />
    ))}
    {[0, 1, 2, 3, 4, 5, 6].map((i) => [0, 1, 2].map((j) => <rect key={`${i}${j}`} x={i * 290 + j * 70 + 10} y={260 + (i % 3) * 50} width={40} height={56} fill="#7fb3d0" stroke={O} strokeWidth={2.5} />))}
    <rect y={650} width={W} height={300} fill="#6f7479" />
    <rect y={940} width={W} height={140} fill="#585d62" />
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <rect key={i} x={i * 260 + 40} y={1000} width={130} height={14} fill="#f1f1f1" />)}
    <rect y={640} width={W} height={20} fill="#b9b3a8" stroke={O} strokeWidth={3} />
    {/* চায়ের স্টল */}
    <path d="M1260 330 H1860 L1820 430 H1300Z" fill="#d9503f" stroke={O} strokeWidth={4} />
    {[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${1300 + i * 100} 430 L${1280 + i * 120} 330`} stroke="#fff" strokeWidth={14} opacity={0.8} />)}
    <rect x={1290} y={430} width={20} height={330} fill="#7a5a30" stroke={O} strokeWidth={3} />
    <rect x={1810} y={430} width={20} height={330} fill="#7a5a30" stroke={O} strokeWidth={3} />
    <rect x={1290} y={620} width={540} height={26} fill="#7a5a30" stroke={O} strokeWidth={3} />
    <ellipse cx={1400} cy={590} rx={50} ry={34} fill="#999" stroke={O} strokeWidth={3} />
    <Cup x={1560} y={600} s={0.9} /><Cup x={1640} y={600} s={0.9} /><Cup x={1720} y={600} s={0.9} />
    <rect x={1330} y={760} width={90} height={26} fill="#7a5a30" stroke={O} strokeWidth={3} />
    <rect x={1700} y={760} width={90} height={26} fill="#7a5a30" stroke={O} strokeWidth={3} />
  </g>
);

/** 'নিলয় টেক কেয়ার' সার্ভিস সেন্টারের সামনের দৃশ্য */
export const Facade: React.FC<{swing?: number}> = ({swing = 0}) => (
  <g>
    <Street />
    <rect x={380} y={200} width={1160} height={700} fill="#f2f6f8" stroke={O} strokeWidth={5} />
    <rect x={380} y={200} width={1160} height={60} fill="#27456b" stroke={O} strokeWidth={4} />
    <rect x={440} y={470} width={420} height={360} fill="#a9d6ea" stroke={O} strokeWidth={5} />
    <rect x={1060} y={470} width={420} height={360} fill="#a9d6ea" stroke={O} strokeWidth={5} />
    <rect x={880} y={470} width={160} height={430} fill="#4a6fa5" stroke={O} strokeWidth={5} />
    <path d="M470 700 H830 M1090 700 H1450" stroke="#fff" strokeWidth={6} opacity={0.6} />
    <g transform={`rotate(${swing},960,290)`}>
      <path d="M700 290 V310 M1220 290 V310" stroke={O} strokeWidth={5} />
      <rect x={560} y={310} width={800} height={130} rx={16} fill="#1f8a5b" stroke={O} strokeWidth={6} />
      <text x={960} y={400} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={78} fill="#fff">নিলয় টেক কেয়ার</text>
    </g>
  </g>
);

/** মোশন গ্রাফিক্স ব্যাকগ্রাউন্ড: সফট ভিনিয়েট */
export const MoBg: React.FC<{hue?: 'green' | 'navy'}> = ({hue = 'green'}) => (
  <g>
    <defs>
      <radialGradient id={`mo-${hue}`} cx="50%" cy="45%" r="75%">
        <stop offset="0" stopColor={hue === 'green' ? '#2c6a5d' : '#2e4a7a'} />
        <stop offset="1" stopColor={hue === 'green' ? '#0e2a26' : '#0f1c36'} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#mo-${hue})`} />
    {Array.from({length: 40}).map((_, i) => <circle key={i} cx={(i * 211) % W} cy={(i * 137) % H} r={3 + (i % 4)} fill="#fff" opacity={0.05 + (i % 3) * 0.02} />)}
  </g>
);
