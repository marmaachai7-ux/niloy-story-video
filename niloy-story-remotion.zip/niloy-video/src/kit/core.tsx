import React, {createContext, useContext} from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {FPS} from '../data';

export const {fontFamily: FONT} = loadFont('normal', {weights: ['500', '600', '700'], subsets: ['bengali', 'latin']});

const SceneStart = createContext(0);
export const SceneProvider = SceneStart.Provider;
/** গ্লোবাল সময় (সেকেন্ড) — সিনের ভেতর থেকেও কাজ করে */
export const useT = () => useContext(SceneStart) + useCurrentFrame() / FPS;

export const ramp = (t: number, a: number, b: number, from = 0, to = 1) =>
  interpolate(t, [a, b], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
/** ০→১ ওভারশুট পপ-ইন */
export const pop = (t: number, t0: number, dur = 0.35) => {
  const p = Math.min(1, Math.max(0, (t - t0) / dur));
  if (p <= 0) return 0;
  return 1 + 2.70158 * Math.pow(p - 1, 3) + 1.70158 * Math.pow(p - 1, 2);
};
/** পপ-ইন + পপ-আউট */
export const popio = (t: number, a: number, b: number) => pop(t, a) * (1 - ramp(t, b - 0.2, b));
export const win = (t: number, a: number, b: number) => t >= a && t < b;
export const lerpPos = (t: number, a: number, b: number, x0: number, x1: number) => ramp(t, a, b, x0, x1);

export type Cam = {t0: number; t1: number; s0: number; s1: number; ox: number; oy: number};
export const applyCam = (x: number, y: number, cam: Cam | undefined, t: number): [number, number] => {
  if (!cam) return [x, y];
  const s = ramp(t, cam.t0, cam.t1, cam.s0, cam.s1);
  return [cam.ox + (x - cam.ox) * s, cam.oy + (y - cam.oy) * s];
};

/** সিন র‍্যাপার: ফেড-ইন, জুম, স্ক্রিন-শেক, ফিল্টার */
export const Frame: React.FC<{
  children: React.ReactNode;
  cam?: Cam;
  shake?: [number, number, number][]; // [t0,t1,amp]
  filter?: string;
  fade?: boolean;
}> = ({children, cam, shake = [], filter, fade = true}) => {
  const t = useT();
  const f = useCurrentFrame();
  const s = cam ? ramp(t, cam.t0, cam.t1, cam.s0, cam.s1) : 1;
  let sx = 0;
  let sy = 0;
  shake.forEach(([a, b, amp]) => {
    if (t >= a && t < b) {
      sx += Math.sin(f * 7.3) * amp;
      sy += Math.cos(f * 9.1) * amp;
    }
  });
  const op = fade ? ramp(f, 0, 8) : 1;
  return (
    <AbsoluteFill style={{opacity: op, overflow: 'hidden'}}>
      <AbsoluteFill
        style={{
          transform: `translate(${sx}px,${sy}px) scale(${s})`,
          transformOrigin: cam ? `${cam.ox}px ${cam.oy}px` : '50% 50%',
          filter,
        }}
      >
        <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{display: 'block'}}>
          {children}
        </svg>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
