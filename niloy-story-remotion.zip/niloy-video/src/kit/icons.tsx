import React from 'react';
import {FONT} from './core';

const O = '#222222';
type P = {x?: number; y?: number; s?: number; r?: number; o?: number};
const G: React.FC<P & {children: React.ReactNode}> = ({x = 0, y = 0, s = 1, r = 0, o = 1, children}) => (
  <g transform={`translate(${x},${y}) rotate(${r}) scale(${s})`} opacity={o}>{children}</g>
);
const st = {stroke: O, strokeWidth: 3.5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export const Phone: React.FC<P & {state?: 'dead' | 'on' | 'cracked' | 'burnt'}> = ({state = 'dead', ...p}) => (
  <G {...p}>
    <rect x={-34} y={-62} width={68} height={124} rx={12} fill="#34495e" {...st} />
    <rect x={-27} y={-50} width={54} height={96} rx={5} fill={state === 'on' ? '#7fe0a8' : '#15191d'} stroke={O} strokeWidth={2} />
    {state === 'on' && <rect x={-22} y={-42} width={44} height={10} rx={3} fill="#e8fff3" opacity={0.8} />}
    {state === 'cracked' && <path d="M-20 -40 L0 -5 L22 -30 M0 -5 L-8 38" stroke="#aab" strokeWidth={2} fill="none" />}
    {state === 'burnt' && <circle cx={6} cy={10} r={16} fill="#3a2a1a" opacity={0.9} />}
    <circle cx={0} cy={54} r={3.5} fill="#aab" />
  </G>
);

export const Multimeter: React.FC<P & {value?: string}> = ({value = '0.00', ...p}) => (
  <G {...p}>
    <rect x={-60} y={-95} width={120} height={190} rx={18} fill="#f2c230" {...st} />
    <rect x={-46} y={-78} width={92} height={46} rx={6} fill="#b8d8a8" stroke={O} strokeWidth={3} />
    <text x={40} y={-44} textAnchor="end" fontFamily="monospace" fontWeight={700} fontSize={32} fill="#1d2b17">{value}</text>
    <circle cx={0} cy={22} r={30} fill="#333" {...st} />
    <path d="M0 22 L16 8" stroke="#f5f5f5" strokeWidth={5} strokeLinecap="round" />
    {[-30, 0, 30].map((q) => <circle key={q} cx={q} cy={78} r={7} fill="#111" stroke={O} strokeWidth={2} />)}
  </G>
);

export const Solder: React.FC<P> = (p) => (
  <G {...p}>
    <rect x={-70} y={-12} width={95} height={24} rx={12} fill="#333" {...st} />
    <rect x={25} y={-8} width={40} height={16} fill="#bbb" {...st} />
    <path d="M65 -4 L95 0 L65 4 Z" fill="#e65c2f" {...st} />
  </G>
);

export const Charger: React.FC<P> = (p) => (
  <G {...p}>
    <rect x={-32} y={-32} width={64} height={64} rx={8} fill="#f1f1f1" {...st} />
    <rect x={-12} y={-52} width={6} height={20} fill="#999" stroke={O} strokeWidth={2} />
    <rect x={6} y={-52} width={6} height={20} fill="#999" stroke={O} strokeWidth={2} />
    <path d="M0 32 Q-6 70 -40 78" fill="none" stroke={O} strokeWidth={5} strokeLinecap="round" />
  </G>
);

export const Key: React.FC<P> = (p) => (
  <G {...p}>
    <circle cx={-22} cy={0} r={17} fill="#e8b93a" {...st} />
    <circle cx={-22} cy={0} r={6} fill="#fff" stroke={O} strokeWidth={2.5} />
    <path d="M-5 0 H44 M32 0 V14 M42 0 V12" fill="none" stroke={O} strokeWidth={7} strokeLinecap="round" />
    <path d="M-5 0 H44 M32 0 V14 M42 0 V12" fill="none" stroke="#e8b93a" strokeWidth={3.5} strokeLinecap="round" />
  </G>
);

export const Coin: React.FC<P> = (p) => (
  <G {...p}>
    <circle r={28} fill="#f2c230" {...st} />
    <circle r={20} fill="none" stroke="#c99a12" strokeWidth={3} />
    <text y={11} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={32} fill="#7a5a00">৳</text>
  </G>
);

export const Note: React.FC<P> = (p) => (
  <G {...p}>
    <rect x={-42} y={-22} width={84} height={44} rx={5} fill="#9fd19a" {...st} />
    <circle r={11} fill="#d9f0d6" stroke={O} strokeWidth={2.5} />
  </G>
);

export const TinBox: React.FC<P & {lift?: number}> = ({lift = 0, ...p}) => (
  <G {...p}>
    <rect x={-60} y={-20} width={120} height={64} rx={8} fill="#b8b8c2" {...st} />
    <rect x={-66} y={-46 - lift} width={132} height={30} rx={8} fill="#cfcfd8" {...st} transform={`rotate(${-lift * 0.5},-66,-16)`} />
    <rect x={-40} y={-2} width={80} height={14} rx={4} fill="#8d8d9a" opacity={0.6} />
  </G>
);

export const Bowl: React.FC<P & {steam?: number}> = ({steam = 0, ...p}) => (
  <G {...p}>
    <path d="M-48 -10 H48 Q44 36 0 40 Q-44 36 -48 -10Z" fill="#f4efe6" {...st} />
    <ellipse cx={0} cy={-10} rx={48} ry={9} fill="#e0a73a" {...st} />
    {steam > 0 && [-18, 0, 18].map((q, i) => (
      <path key={q} d={`M${q} -26 q-10 -14 0 -28 q10 -14 0 -28`} fill="none" stroke="#ddd" strokeWidth={5} strokeLinecap="round" opacity={steam * (0.7 - i * 0.1)} />
    ))}
  </G>
);

export const Plate: React.FC<P & {steam?: number}> = ({steam = 0, ...p}) => (
  <G {...p}>
    <ellipse cx={0} cy={0} rx={70} ry={16} fill="#f4efe6" {...st} />
    <path d="M-40 -2 Q0 -38 40 -2 Z" fill="#fff" {...st} />
    {steam > 0 && [-14, 14].map((q) => (
      <path key={q} d={`M${q} -34 q-10 -14 0 -26 q10 -14 0 -26`} fill="none" stroke="#e6e6e6" strokeWidth={5} strokeLinecap="round" opacity={steam} />
    ))}
  </G>
);

export const Notebook: React.FC<P> = (p) => (
  <G {...p}>
    <rect x={-44} y={-58} width={88} height={116} rx={6} fill="#f6efd8" {...st} />
    <rect x={-44} y={-58} width={12} height={116} fill="#c0564a" {...st} />
    {[-30, -12, 6, 24].map((q) => <path key={q} d={`M-22 ${q} H34`} stroke="#6a6a8a" strokeWidth={3} strokeLinecap="round" />)}
    <path d="M10 38 l8 -8 l8 8" fill="none" stroke="#c0564a" strokeWidth={3} />
  </G>
);

export const Bulb: React.FC<P & {on?: boolean}> = ({on = true, ...p}) => (
  <G {...p}>
    {on && [0, 60, 120, 180, 240, 300].map((a) => <path key={a} d="M0 -62 V-84" stroke="#f2c230" strokeWidth={6} strokeLinecap="round" transform={`rotate(${a})`} />)}
    <circle r={40} fill={on ? '#ffe27a' : '#ddd'} {...st} />
    <rect x={-18} y={36} width={36} height={22} rx={5} fill="#aaa" {...st} />
  </G>
);

export const Calendar: React.FC<P & {label?: string; top?: string}> = ({label = '৭', top = 'দিন', ...p}) => (
  <G {...p}>
    <rect x={-70} y={-70} width={140} height={140} rx={16} fill="#fff" {...st} />
    <path d="M-70 -70 H70 V-30 H-70Z" fill="#d9503f" {...st} />
    <circle cx={-34} cy={-76} r={7} fill="#444" /><circle cx={34} cy={-76} r={7} fill="#444" />
    <text y={-40} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={26} fill="#fff">{top}</text>
    <text y={44} textAnchor="middle" fontFamily={FONT} fontWeight={700} fontSize={76} fill="#222">{label}</text>
  </G>
);

export const Check: React.FC<P> = (p) => (
  <G {...p}><circle r={30} fill="#3fae6a" {...st} /><path d="M-14 0 L-4 11 L15 -10" fill="none" stroke="#fff" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" /></G>
);
export const Cross: React.FC<P> = (p) => (
  <G {...p}><circle r={30} fill="#d9503f" {...st} /><path d="M-12 -12 L12 12 M12 -12 L-12 12" stroke="#fff" strokeWidth={8} strokeLinecap="round" /></G>
);
export const Arrow: React.FC<P & {len?: number; color?: string}> = ({len = 120, color = '#f2c230', ...p}) => (
  <G {...p}>
    <path d={`M0 0 H${len}`} stroke={O} strokeWidth={16} strokeLinecap="round" />
    <path d={`M${len - 22} -24 L${len + 8} 0 L${len - 22} 24`} fill="none" stroke={O} strokeWidth={16} strokeLinecap="round" strokeLinejoin="round" />
    <path d={`M0 0 H${len}`} stroke={color} strokeWidth={9} strokeLinecap="round" />
    <path d={`M${len - 22} -24 L${len + 8} 0 L${len - 22} 24`} fill="none" stroke={color} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
  </G>
);
export const Smoke: React.FC<P & {t?: number}> = ({t = 0, ...p}) => (
  <G {...p}>
    {[0, 1, 2].map((i) => (
      <circle key={i} cx={Math.sin(t * 3 + i) * 10} cy={-((t * 40 + i * 28) % 84)} r={14 + i * 3} fill="#777" opacity={0.55 - ((t * 40 + i * 28) % 84) / 200} />
    ))}
  </G>
);
export const Moon: React.FC<P> = (p) => (
  <G {...p}><circle r={46} fill="#f6f0c8" stroke="none" /><circle cx={16} cy={-8} r={40} fill="#14213d" /></G>
);
export const Trophy: React.FC<P> = (p) => (
  <G {...p}>
    <path d="M-46 -60 H46 V-20 Q46 30 0 36 Q-46 30 -46 -20Z" fill="#f2c230" {...st} />
    <path d="M-46 -48 Q-82 -48 -70 -14 Q-60 6 -44 4 M46 -48 Q82 -48 70 -14 Q60 6 44 4" fill="none" {...st} />
    <rect x={-8} y={34} width={16} height={34} fill="#d9a520" {...st} />
    <rect x={-40} y={66} width={80} height={20} rx={5} fill="#7a5a30" {...st} />
  </G>
);
export const Cup: React.FC<P> = (p) => (
  <G {...p}>
    <path d="M-22 -18 H22 L18 24 H-18Z" fill="#f7f0e6" {...st} />
    <path d="M22 -8 Q40 -6 36 8 Q32 16 20 14" fill="none" {...st} />
    <path d="M-22 -18 H22 L21 -8 H-21Z" fill="#c78a4a" />
  </G>
);
export const Torch: React.FC<P & {beam?: number}> = ({beam = 1, ...p}) => (
  <G {...p}>
    {beam > 0 && <path d="M0 0 L-260 640 L260 640 Z" fill="#fff6b0" opacity={0.28 * beam} />}
    <circle r={7} fill="#fff6b0" />
  </G>
);
export const People: React.FC<P> = (p) => (
  <G {...p}>
    {[-52, 0, 52].map((q, i) => (
      <g key={q} transform={`translate(${q},${i === 1 ? -6 : 8})`}>
        <circle cy={-30} r={20} fill="#c68b59" {...st} />
        <path d="M-28 40 Q-28 -4 0 -4 Q28 -4 28 40Z" fill={['#e07a9b', '#27456b', '#e0a82e'][i]} {...st} />
      </g>
    ))}
  </G>
);
export const ShopIcon: React.FC<P & {empty?: boolean}> = ({empty, ...p}) => (
  <G {...p}>
    <rect x={-60} y={-30} width={120} height={80} fill="#d9c9a3" {...st} />
    <path d="M-70 -30 L-56 -62 H56 L70 -30Z" fill="#c0564a" {...st} />
    <rect x={-16} y={4} width={32} height={46} fill="#7a5a30" {...st} />
    {!empty && <circle cx={-38} cy={20} r={8} fill="#f2c230" stroke={O} strokeWidth={2} />}
  </G>
);
export const Quote: React.FC<P> = (p) => (
  <G {...p}><text textAnchor="middle" fontFamily="Georgia, serif" fontWeight={700} fontSize={220} fill="#f2c230">“</text></G>
);
